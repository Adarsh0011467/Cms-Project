const router=require('express').Router()
const multer = require('multer')
const regc=require('../controllers/regcontroller')

function handlerole(req,res,next){
  if(req.session.role=='pvt'){
    next()
  }else{
    res.send('you don"t have right to see this page')
  }
}

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})

const upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*50}
})

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/login')
    }
}

router.get('/',handlelogin,regc.homepage)
router.get('/reg',regc.regform)
router.post('/reg',regc.reginsert)
router.get('/login',regc.loginshow)
router.post('/login',regc.logincheck)
router.get('/logout',regc.logout)
router.get('/emailverify/:email',regc.emailverify)
router.get('/profile',handlelogin,regc.profile)
router.post('/profile',upload.single('img'),regc.profileupdate)
router.get('/testi',handlelogin,handlerole,regc.testi)
router.get('/forgotpassword',regc.forgotshow)
router.post('/forgotpassword',regc.forgotdata)
router.get('/forgotmessage',regc.forgotmessage)
router.get('/changepassword/:email',regc.forgotlink)
router.post('/forgotpasswordnew/:email',regc.forgotpasswordupdate)
router.get('/changepassword',regc.changepasswordshow)
router.post('/changepassword',regc.changepassword)
router.get('/profiledetails/:id',handlelogin,handlerole,regc.profiledetailsfront)












module.exports=router